const ProjectActions = require('./project-actions');
new ProjectActions().run();
