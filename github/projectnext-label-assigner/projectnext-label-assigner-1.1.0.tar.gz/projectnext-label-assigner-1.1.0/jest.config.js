module.exports = {
  clearMocks: true,
  moduleFileExtensions: ['js'],
  testEnvironment: 'node',
  testMatch: ['**/*.test.js'],
  verbose: true
}
