# **Support**

## Obtain direct support from the project's owners

1. Open a new issue and select the issue with the template called "❓ Question or Support Request".
2. Read the instructions carefully in that template and submit the issue asking for support
or any question.

## Bug reports

See the [contributing guidelines](CONTRIBUTING.md) for sharing bug reports and read our [code of conduct](CODE_OF_CONDUCT.md).
