---
name: "❓ Question or Support Request"
about: "Questions and requests for support."
title: ""
labels: "Type: Question"
assignees: codedesignplus

---

# **❓ Question or Support Request**

## **Describe your question or ask for support.**
<!-- A clear and concise description of what your doubt is. -->

*

<!--📛📛📛📛📛📛📛📛📛📛📛📛📛📛📛📛📛📛📛📛📛📛📛📛📛📛📛📛📛📛

Oh, hi there! 😄

Before posting any questions or asking for support, first read the project's README.md file and
(if there is any) the WIKI pages or any other additional documentation that might be listed
in the project's README.md file.

To expedite issue processing, please search open and closed issues before submitting a new one.
Please read our Rules of Conduct at this repository's `.github/CODE_OF_CONDUCT.md`

📛📛📛📛📛📛📛📛📛📛📛📛📛📛📛📛📛📛📛📛📛📛📛📛📛📛📛📛📛📛📛📛-->
