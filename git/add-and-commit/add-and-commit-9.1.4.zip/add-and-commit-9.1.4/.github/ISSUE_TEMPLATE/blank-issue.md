---
name: Blank issue
about: Just a blank template
title: ''
labels: 'status: pending'
assignees: ''

---


