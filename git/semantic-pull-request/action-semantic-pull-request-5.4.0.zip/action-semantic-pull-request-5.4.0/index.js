const run = require('./src');

run();
